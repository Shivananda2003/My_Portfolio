from flask import Flask, render_template, request, redirect, flash, url_for
from flask_mail import Mail, Message

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a strong secret key

# --- Mail Configuration ---
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'shivanandadora@gmail.com'          # ← Your Gmail
app.config['MAIL_PASSWORD'] = 'nckg blfx saqi qyzg'             # ← App Password from Google
app.config['MAIL_DEFAULT_SENDER'] = 'your_email@gmail.com'    # ← Must match MAIL_USERNAME

mail = Mail(app)

# --- Home Route with Contact Form ---
@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')

        try:
            msg = Message(subject=f"New Contact from {name}",
                          recipients=['shivanandadora@gmail.com'])  # ← Your receiving email
            msg.body = f"Name: {name}\nEmail: {email}\n\nMessage:\n{message}"
            mail.send(msg)
            flash('Your message has been sent!', 'success')
        except Exception as e:
            flash(f"Failed to send message: {str(e)}", 'danger')

        return redirect(url_for('home') + '#contact')

    return render_template('home.html', title="My Portfolio")

# --- Run the app ---
if __name__ == "__main__":
    app.run(debug=True)
